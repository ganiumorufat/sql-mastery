# SQL Mastery — Module 3: conditional logic

Total questions: **25**

Use the included SQLite database to solve the questions.

## Beginner

1. Classify each product as Expensive if the price is at least 300; otherwise classify it as Affordable.

2. Classify each customer as Canada if they are from Canada; otherwise classify them as International.

3. Label each order as Finalized if its status is Completed; otherwise label it as Not Finalized.

4. Categorize each product as Low Price, Medium Price, or High Price: below 100 is Low Price, 100–299.99 is Medium Price, and at least 300 is High Price.

5. Label each customer as Local if they are from Montreal; otherwise label them as Other.

## Easy

6. Calculate the number of Expensive and Affordable products.

7. Calculate the number of Canadian and International customers.

8. Calculate the number of Finalized and Not Finalized orders.

9. Calculate total revenue generated from Expensive products.

10. Calculate total revenue generated from Affordable products.

## Intermediate

11. Calculate the percentage of products classified as Expensive.

12. Calculate the percentage of customers from Canada.

13. Calculate the percentage of Completed orders.

14. Calculate the revenue split between Electronics and Non-Electronics products.

15. Calculate the quantity sold by product price level using Low Price below 100, Medium Price from 100 to below 300, and High Price at least 300.

## Advanced

16. Calculate total revenue for each customer and classify them as High Value when revenue is at least 1000, Medium Value when revenue is at least 300, and Low Value otherwise.

17. Calculate total quantity sold for each product and classify it as Best Seller when total quantity sold is at least 5; otherwise classify it as Normal.

18. Calculate total revenue for each product category and classify it as High Revenue when its revenue is at or above the average category revenue; otherwise classify it as Low Revenue.

19. Calculate the Completed order rate for each country.

20. Create an order status summary for each customer showing Has Cancelled Order or No Cancelled Order.

## Interview Style

21. Calculate the overall cancellation rate using conditional aggregation.

22. Calculate the Completed order rate by country using conditional aggregation.

23. Calculate revenue generated from Completed orders only.

24. Identify customers whose Completed order revenue is greater than their Cancelled order revenue.

25. Identify products where more than 50% of the quantity sold came from Completed orders.
