# SQL Mastery — Module 8: ranking & top-n

Total questions: **20**

Use the included SQLite database to solve the questions.

## Beginner

1. Identify the most expensive product.

2. Identify the least expensive product.

3. Identify the three most expensive products.

4. Identify the most expensive product in each category.

5. Identify the two most expensive products in each category.

## Customer & Product Rankings

6. Identify the customer who generated the highest total revenue.

7. Identify the top three customers by total revenue.

8. Identify the highest-revenue customer in each country.

9. Identify the product with the highest quantity sold.

10. Identify the best-selling product by quantity in each category.

## Order & Employee Rankings

11. Identify the latest order placed by each customer.

12. Identify the first order placed by each customer.

13. Identify the second order placed by each customer.

14. Identify the highest-paid employee in each department using each employee's latest salary.

15. Identify the second-highest-paid employee in each department using distinct latest salary levels.

16. Identify the most recently hired employee in each department.

17. Identify the longest-serving employee in each department.

18. Identify the two departments with the highest average latest salary.

## Advanced

19. Identify all products tied for the highest total revenue.

20. Demonstrate when to use RANK() instead of ROW_NUMBER() by comparing both functions on products ordered by price.
